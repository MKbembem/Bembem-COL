using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zed
{
    public class DangerDB
    {


        public static List<String> DangerousList = new List<string>()
        {            
            "AatroxQ",
            "AhriSeduce",
            "CurseoftheSadMummy",
            "InfernalGuardian", 
            "EnchantedCrystalArrow",
            "AzirR", 
            "BrandWildfire",
            "CassiopeiaPetrifyingGaze",
            "DariusExecute",
            "DravenRCast",
            "EvelynnR",
            "EzrealTrueshotBarrage",
            "Terrify",
            "GalioIdolOfDurand",
            "GarenR",
            "GravesChargeShot",
            "HecarimUlt",
            "LissandraR",
            "LuxMaliceCannon",
            "UFSlash",                
            "AlZaharNetherGrasp",
            "OrianaDetonateCommand",
            "LeonaSolarFlare",
            "SejuaniGlacialPrisonStart",
            "SonaCrescendo",
            "VarusR",
            "GragasR",
            "GnarR",
            "FizzMarinerDoom",
            "SyndraR"
            
        };
    }
}
